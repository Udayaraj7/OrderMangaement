sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("approvers.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);